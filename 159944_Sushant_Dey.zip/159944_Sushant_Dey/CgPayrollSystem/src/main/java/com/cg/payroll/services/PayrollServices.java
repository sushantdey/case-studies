package com.cg.payroll.services;
import java.util.ArrayList;

import com.cg.payroll.beans.*;
public interface PayrollServices {
	Associate acceptAssociateDetails(Associate associate);
	int calculateNetSalary(int associateId);
	Associate getAssociateDetails(int associateId);
	ArrayList<Associate>getAllAsociateDetails();
}
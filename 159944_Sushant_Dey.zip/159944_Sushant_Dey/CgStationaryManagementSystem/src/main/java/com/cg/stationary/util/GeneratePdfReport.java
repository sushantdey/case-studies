package com.cg.stationary.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.List;

import com.cg.stationary.beans.Order;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class GeneratePdfReport {
		public static ByteArrayInputStream ordersReport(List<Order> orders) throws DocumentException {

		Document document = new Document();
		ByteArrayOutputStream out = new ByteArrayOutputStream();

		PdfPTable table = new PdfPTable(5);
		table.setWidthPercentage(100);
		//table.setWidths(new int[]{1, 16, 16});
		
		Font headFont = FontFactory.getFont(FontFactory.COURIER_BOLD, 8);
		PdfPCell hcell;
		hcell = new PdfPCell(new Phrase("Order Id", headFont));
		//hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(hcell);
		hcell = new PdfPCell(new Phrase("Associate Id", headFont));
		//hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(hcell);
		hcell = new PdfPCell(new Phrase("Item Id", headFont));
		//hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(hcell);
		hcell = new PdfPCell(new Phrase("Item Name", headFont));
		//hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(hcell);
		hcell = new PdfPCell(new Phrase("Item Count", headFont));
		table.addCell(hcell);
		
		Font bodyFont = FontFactory.getFont(FontFactory.COURIER, 8);

		for (Order order : orders) {

			PdfPCell cell;

			cell = new PdfPCell(new Phrase(String.valueOf(order.getOrderID()),bodyFont));
			table.addCell(cell);

			cell = new PdfPCell(new Phrase(String.valueOf(order.getAssociate().getAssociateId()),bodyFont));
			table.addCell(cell);
			
			cell = new PdfPCell(new Phrase(String.valueOf(order.getItem().getItemId()),bodyFont));
			table.addCell(cell);
			
			cell = new PdfPCell(new Phrase(order.getItem().getItemName(),bodyFont));
			table.addCell(cell);
			
			cell = new PdfPCell(new Phrase(String.valueOf(order.getCount()),bodyFont));
			table.addCell(cell);
			
		}

		PdfWriter.getInstance(document, out);
		document.open();
		//document.addTitle("All Bills Details");
		//document.add("All Bills Details");
		document.add(new Paragraph("Order Details"));
		document.add(table);
		document.close();

		return new ByteArrayInputStream(out.toByteArray());
	}
}

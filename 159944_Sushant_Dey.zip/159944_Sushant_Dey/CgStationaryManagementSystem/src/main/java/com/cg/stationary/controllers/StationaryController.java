package com.cg.stationary.controllers;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.stationary.beans.Associate;
import com.cg.stationary.beans.Item;
import com.cg.stationary.beans.Order;
import com.cg.stationary.exceptions.AssociateNotFoundException;
import com.cg.stationary.exceptions.IncorrectItemNameException;
import com.cg.stationary.exceptions.InsufficientStockException;
import com.cg.stationary.exceptions.ItemAlreadyExistsException;
import com.cg.stationary.exceptions.ItemNotFoundException;
import com.cg.stationary.exceptions.ItemsNotFoundException;
import com.cg.stationary.exceptions.OrderNotFoundException;
import com.cg.stationary.exceptions.StationaryServicesDownException;
import com.cg.stationary.services.StationaryServices;
import com.cg.stationary.util.GeneratePdfReport;
import com.itextpdf.text.DocumentException;
@Controller
public class StationaryController {
	@Autowired
	private StationaryServices stationaryServices;
	Associate associate;
	Order order;
	Item item;
	@RequestMapping(value = "/allOrdersPdfReport", method = RequestMethod.GET,
            produces = MediaType.APPLICATION_PDF_VALUE )
    public ResponseEntity<InputStreamResource> viewAllOrdersPdfReport() throws IOException {

        List<Order> orders = new ArrayList<>();
		try {
			orders = stationaryServices.viewAllOrders();
		} catch (StationaryServicesDownException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (OrderNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

        ByteArrayInputStream bis;
		try {
			bis = GeneratePdfReport.ordersReport(orders);

        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", "inline; filename=billsreport.pdf");

        return ResponseEntity
                .ok()
                .headers(headers)
                .contentType(MediaType.APPLICATION_PDF)
                .body(new InputStreamResource(bis));
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
    }
	@RequestMapping(value = "/associateAllOrdersPdfReport", method = RequestMethod.GET,
            produces = MediaType.APPLICATION_PDF_VALUE )
    public ResponseEntity<InputStreamResource> viewAssociateAllOrdersPdfReport(@RequestParam("associateId")int associateId) throws IOException {

        List<Order> orders = new ArrayList<>();
		try {
			orders = stationaryServices.viewAssociateAllOrders(associateId);
		} catch (StationaryServicesDownException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (AssociateNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (OrderNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

        ByteArrayInputStream bis;
		try {
			bis = GeneratePdfReport.ordersReport(orders);

        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", "inline; filename=billsreport.pdf");

        return ResponseEntity
                .ok()
                .headers(headers)
                .contentType(MediaType.APPLICATION_PDF)
                .body(new InputStreamResource(bis));
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
    }
	@RequestMapping("/allItemDetails")
	public ModelAndView viewAllItemDetails() {
		List<Item> items;
		try {
			items = stationaryServices.viewAllItems();
			if(items==null)
				throw new ItemsNotFoundException();
		} catch (StationaryServicesDownException e) {
			return new ModelAndView("indexPage", "errorMessage", "Error Occured!!!!!Please Try Again");
		} catch (ItemsNotFoundException e) {
			return new ModelAndView("indexPage", "errorMessage", "No Items Found!!! Please Try Again.");
		}
		return new ModelAndView("displayAllItemsPage", "items", items);
	}
	@RequestMapping("/registerAssociate")
	public ModelAndView registerAssociateAction(@Valid@ModelAttribute Associate associate,BindingResult bindingResultAssociate)  {
		if(bindingResultAssociate.hasErrors())
			return new ModelAndView("registerPage");

		int associateId;
		try {
			associateId = stationaryServices.registerAssociate(associate);
		} catch (StationaryServicesDownException e) {
			return new ModelAndView("registerPage", "errorMessage", "Error Occured!!!!!Please Try Again");
		}
		return new ModelAndView("registrationSuccessPage", "associateId", associateId);
	}
	@RequestMapping("/insertItem")
	public ModelAndView insertItemAction(@Valid@ModelAttribute Item item,BindingResult bindingResultItem)  {
		if(bindingResultItem.hasErrors())
			return new ModelAndView("insertItemToListPage","errorMessage", "Error Occured!!!!!Please Try Again");
		int itemId;
		try {
			itemId = stationaryServices.addItemToList(item);
		} catch (StationaryServicesDownException e) {
			return new ModelAndView("insertItemToListPage", "errorMessage", "Error Occured!!!!!Please Try Again");
		} catch (ItemAlreadyExistsException e) {
			return new ModelAndView("insertItemToListPage", "errorMessage", "Item Already Exists!!! Please Try Updating the Item.");
		}
		String message = "Item inserted successfully. Item Id: "+itemId;
		return new ModelAndView("adminIndexPage", "message",message );
	}
	@RequestMapping("/updateItem")
	public ModelAndView updateItemAction(@Valid@ModelAttribute Item item,BindingResult bindingResultItem)  {
		if(bindingResultItem.hasErrors())
			return new ModelAndView("updateItemListPage","errorMessage", "Error Occured!!!!!Please Try Again");
		try {
			stationaryServices.updateItemList(item);
		} catch (StationaryServicesDownException e) {
			return new ModelAndView("updateItemListPage", "errorMessage", "Error Occured!!!!!Please Try Again");
		} catch (ItemNotFoundException e) {
			return new ModelAndView("updateItemListPage", "errorMessage", "Invalid Item ID!!! Please Try Again.");
		} catch (IncorrectItemNameException e) {
			return new ModelAndView("updateItemListPage", "errorMessage", "Invalid Item Name!!! Please Try Again.");
		}
		return new ModelAndView("adminIndexPage", "message","Item inserted successfully" );
	}
	@RequestMapping("/deleteItem")
	public ModelAndView deleteItemAction(@Valid@ModelAttribute Item item,BindingResult bindingResultItem)  {
		if(bindingResultItem.hasErrors())
			return new ModelAndView("deleteItemFromListPage","errorMessage", "Error Occured!!!!!Please Try Again");
		try {
			stationaryServices.deleteItemFromList(item);
		} catch (StationaryServicesDownException e) {
			return new ModelAndView("adminIndexPage", "errorMessage", "Error Occured!!!!!Please Try Again");
		} catch (ItemNotFoundException e) {
			return new ModelAndView("adminIndexPage", "errorMessage", "Invalid Item ID!!! Please Try Again.");
		}
		return new ModelAndView("adminIndexPage", "message","Item deleted successfully" );
	}
	@RequestMapping("/orderItem")
	public ModelAndView orderItemAction(@Valid@ModelAttribute Order order,BindingResult bindingResultOrder)  {
		if(bindingResultOrder.hasErrors())
			return new ModelAndView("orderStationaryPage","errorMessage", "Error Occured!!!!!Please Try Again");
		String message;
		try {
			int orderId=stationaryServices.orderStationary(order);
			message = "Order placed  successfully. Order Id is: "+orderId;
		} catch (StationaryServicesDownException e) {
			return new ModelAndView("orderStationaryPage", "errorMessage", "Error Occured!!!!!Please Try Again");
		}  catch (AssociateNotFoundException e) {
			return new ModelAndView("orderStationaryPage", "errorMessage", "Invalid Associate ID!!! Please Try Again.");
		}catch (ItemNotFoundException e) {
			return new ModelAndView("orderStationaryPage", "errorMessage", "Invalid Item ID!!! Please Try Again.");
		} catch (InsufficientStockException e) {
			return new ModelAndView("orderStationaryPage", "errorMessage", "Insufficient Stock!!! Please Try Later.");
		}
		return new ModelAndView("associateIndexPage", "message",message );
	}
	@RequestMapping("/associateAllOrders")
	public ModelAndView viewAssociateOrdersAction(@Valid@ModelAttribute Associate associate)  {
		List<Order> orders;
		try {
			orders = stationaryServices.viewAssociateAllOrders(associate.getAssociateId());
		} catch (StationaryServicesDownException e) {
			return new ModelAndView("viewAssociateOrdersPage", "errorMessage", "Error Occured!!!!!Please Try Again");
		}  catch (AssociateNotFoundException e) {
			return new ModelAndView("viewAssociateOrdersPage", "errorMessage", "Invalid Associate ID!!! Please Try Again.");
		}catch (OrderNotFoundException e) {
			return new ModelAndView("viewAssociateOrdersPage", "errorMessage", "No orders Found!!! Please Try Again.");
		}
		return new ModelAndView("displayOrdersPage", "orders",orders );
	}
	@RequestMapping("/viewAllOrders")
	public ModelAndView viewAllOrdersPage(@Valid@ModelAttribute Associate associate)  {
		List<Order> orders;
		try {
			orders = stationaryServices.viewAllOrders();
		} catch (StationaryServicesDownException e) {
			return new ModelAndView("adminIndexPage", "errorMessage", "Error Occured!!!!!Please Try Again");
		}  catch (OrderNotFoundException e) {
			return new ModelAndView("adminIndexPage", "errorMessage", "No Orders Found!!! Please Try Again.");
		}
		return new ModelAndView("displayAllOrdersPage", "orders",orders );
	}
	@RequestMapping("/CancelOrder")
	public ModelAndView CancelOrderAction(@RequestParam(name="associateId")int associateId,@RequestParam(name="orderId")int orderId)  {
		try {
			stationaryServices.cancelOrder(associateId, orderId);
		} catch (StationaryServicesDownException e) {
			return new ModelAndView("cancelOrderPage", "errorMessage", "Error Occured!!!!!Please Try Again");
		}  catch (AssociateNotFoundException e) {
			return new ModelAndView("cancelOrderPage", "errorMessage", "Associate Not Found!!!!!Please Try Again");
		} catch (OrderNotFoundException e) {
			return new ModelAndView("cancelOrderPage", "errorMessage", "Invalid Order Id!!!!!Please Try Again");
		}
		return new ModelAndView("associateIndexPage", "message","Order Cancelled Successfully." );
	}
}

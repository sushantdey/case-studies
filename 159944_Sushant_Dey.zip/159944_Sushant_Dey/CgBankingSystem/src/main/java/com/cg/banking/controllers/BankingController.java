package com.cg.banking.controllers;
import java.util.List;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingService;

@Controller
public class BankingController {
	@Autowired
	private BankingService bankingService;
	Customer customer;
	Account account;
	Transaction transaction;
	@RequestMapping("/registerCustomer")
	public ModelAndView registerCustomerAction(@Valid@ModelAttribute Customer customer,BindingResult bindingResultCustomer,@RequestParam("accounts[0].accountBalance")float accountBalance,@RequestParam("accounts[0].accountType")String accountType) {
		if(bindingResultCustomer.hasErrors())
			return new ModelAndView("registerPage");
		account = new Account(accountType, accountBalance);
		customer=bankingService.openAccount(customer,account);
		return new ModelAndView("registrationSuccessPage", "customer", customer);
	}
	@RequestMapping("/Deposit")
	public ModelAndView depositAction(@Valid@ModelAttribute Account account ,BindingResult bindingResultAccount) throws AccountNotFoundException, BankingServicesDownException{
		float updatedBalance=bankingService.depositAmount(account.getAccountNo(), account.getAccountBalance());
		String message="Transaction Successful. Updated Balance is:"+updatedBalance;
		return new ModelAndView("indexPage", "message", message);
	}
	@RequestMapping("/Withdraw")
	public ModelAndView withdrawAction(@Valid@ModelAttribute Account account ,BindingResult bindingResultAccount) throws AccountNotFoundException, BankingServicesDownException, InsufficientAmountException, InvalidPinNumberException, AccountBlockedException{
		float updatedBalance=bankingService.withdrawAmount(account.getAccountNo(), account.getAccountBalance());
		String message="Transaction Successful. Updated Balance is:"+updatedBalance;
		return new ModelAndView("indexPage", "message", message);
	}
	@RequestMapping("/FundTransfer")
	public ModelAndView fundTransferAction(@RequestParam("accountNoFrom") long accountNoFrom,@RequestParam("accountNoTo") long accountNoTo,@RequestParam("transferAmount") float transferAmount) throws AccountNotFoundException, BankingServicesDownException, InsufficientAmountException, InvalidPinNumberException, AccountBlockedException{
		float updatedBalance=bankingService.fundTransfer(accountNoTo, accountNoFrom, transferAmount);
		String message="Transaction Successful. Updated Balance is:"+updatedBalance;
		return new ModelAndView("indexPage", "message", message);
	}
	@RequestMapping("/displayCustomer")
	public ModelAndView displayCustomerDeatils(@RequestParam("customerId")int customerId) throws AccountNotFoundException, BankingServicesDownException{
		customer=bankingService.getCustomerDetails(customerId);
		return new ModelAndView("displayCustomerDetailsPage", "customer" , customer);
	}
	@RequestMapping("/displayAccountAllTransactions")
	public ModelAndView displayAccountAllTransactions(@RequestParam("accountNo")int accountNo) throws AccountNotFoundException, BankingServicesDownException{
		List<Transaction> listTransaction=bankingService.getAccountAllTransaction(accountNo);
		return new ModelAndView("displayAccountAllTransactionsPage", "listTransaction", listTransaction);
	}
	@RequestMapping("/allAccountDetails")
	public ModelAndView getAllAccountDeatils() throws BankingServicesDownException{
		List<Account> accounts=bankingService.getAllAccountDetails();
		return new ModelAndView("displayAllAccountDetailsPage", "accounts", accounts);
	}
	@RequestMapping("/allCustomerDetails")
	public ModelAndView getAllCustomerDeatils() throws BankingServicesDownException, AccountNotFoundException{
		List<Customer> customers=bankingService.getAllCustomerDetails();
		return new ModelAndView("displayAllCustomerDetailsPage", "customers", customers);
	}
	@RequestMapping("/allTransactionDetails")
	public ModelAndView getAllTransactionDetails() throws BankingServicesDownException, AccountNotFoundException{
		List<Transaction> transactions=bankingService.getAllTransactionDetails();
		return new ModelAndView("displayAllTransactionDetailsPage", "transactions",transactions);
	}
}
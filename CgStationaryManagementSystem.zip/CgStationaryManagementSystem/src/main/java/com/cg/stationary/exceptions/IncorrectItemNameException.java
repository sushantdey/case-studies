package com.cg.stationary.exceptions;

@SuppressWarnings("serial")
public class IncorrectItemNameException extends Exception {

	/**
	 * 
	 */
	public IncorrectItemNameException() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 * @param cause
	 * @param enableSuppression
	 * @param writableStackTrace
	 */
	public IncorrectItemNameException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 * @param cause
	 */
	public IncorrectItemNameException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public IncorrectItemNameException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param cause
	 */
	public IncorrectItemNameException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
}

package com.cg.stationary.daoservices;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.cg.stationary.beans.Item;

@Qualifier("JpaRepository")
public interface ItemDAO extends JpaRepository<Item, Integer> {
	@Modifying
	@Transactional
	@Query(value="UPDATE Item SET item_Count=?2 WHERE item_Id=?1", nativeQuery=false)
	int updateItem(int itemId, int itemCount);
	@Modifying
	@Transactional
	@Query(value="DELETE FROM Item WHERE item_Id=?1", nativeQuery=false)
	int removeItem(int itemId);
}
